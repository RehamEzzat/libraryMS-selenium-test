package newpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Contact_Test
{

	public static void  main(String[]args)
	{
		
		System.setProperty("webdriver.chrome.driver","F:\\FCI_Three\\New folder\\Chrome\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://localhost/library-master");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		

		driver.findElement(By.xpath("//html//li[7]/a[1]")).click();
		
		
		
		
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[1]/div[1]/input[1]")).sendKeys("Islam");
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[2]/div[1]/input[1]")).sendKeys("Zaki");
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[3]/div[1]/input[1]")).sendKeys("Islam_ZaKI@gmail.com");
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[4]/div[1]/input[1]")).sendKeys("I have an Issue with the website");
		driver.findElement(By.xpath("//button[@name='submit']")).click();
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[1]/div[1]/input[1]")).clear();
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[2]/div[1]/input[1]")).clear();
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[3]/div[1]/input[1]")).clear();
		driver.findElement(By.xpath("//html//div[@class='form-horizontal']/div[4]/div[1]/input[1]")).clear();

		
		
		
		//driver.findElement(By.name("FIRST NAME:")).clear();
		//driver.findElement(By.name("FIRST NAME:")).sendKeys("KEYA07");
		
		//driver.findElement(By.name("LAST NAME:")).clear();
		/*driver.findElement(By.name("LAST NAME:")).sendKeys("KEYA07");
				
		driver.findElement(By.name("EMAIL ADDRESS:")).clear();
		driver.findElement(By.name("EMAIL ADDRESS:")).sendKeys("anything' OR 'x'='x");
		
		
		driver.findElement(By.name("MESSAGE:")).clear();
		driver.findElement(By.name("MESSAGE:")).sendKeys("anything' OR 'x'='x");
			
		driver.findElement(By.name("send")).click();*/
	}
}
