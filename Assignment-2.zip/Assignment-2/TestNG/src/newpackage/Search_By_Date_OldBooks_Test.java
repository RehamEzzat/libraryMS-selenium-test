package newpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Search_By_Date_OldBooks_Test {


		public static void main (String []args)
		{
			System.setProperty("webdriver.chrome.driver","F:\\FCI_Three\\New folder\\Chrome\\chromedriver.exe");
			WebDriver driver= new ChromeDriver();
			driver.get("http://localhost/library-master/member/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			
			driver.findElement(By.name("username")).clear();
			driver.findElement(By.name("username")).sendKeys("KEYA07");
			driver.findElement(By.name("password")).clear();
			driver.findElement(By.name("password")).sendKeys("anything' OR 'x'='x");
			driver.findElement(By.name("submit")).click();
			
		
			driver.findElement(By.xpath("//a[@href='#myModal2']")).click();
			
			driver.findElement(By.name("from")).sendKeys("01/01/1990");
			driver.findElement(By.name("to")).sendKeys("01/01/2017");
			
			driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();
			
			
			
			driver.findElement(By.xpath("//a[@href='old_books.php']")).click();
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Networking 2"); //Wrong
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
			
	        driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Networking & Data Communication"); //Wrong
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
	       
	        driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Hwang Kai"); // Wrong
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();

	        driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Architecture."); //Correct
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
			

	        driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Pearson education"); //Wrong
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
			
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("encyclopedia"); //Wrong
			driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
			
	
	}
	
}
