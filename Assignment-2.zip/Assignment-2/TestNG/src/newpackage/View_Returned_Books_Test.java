package newpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class View_Returned_Books_Test
{

	public static void  main(String[]args)
	{
		
		System.setProperty("webdriver.chrome.driver","F:\\FCI_Three\\New folder\\Chrome\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://localhost/library-master/member/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		

		driver.findElement(By.name("username")).clear();
		driver.findElement(By.name("username")).sendKeys("Keya07");
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("anything' OR 'x'='x");
		driver.findElement(By.name("submit")).click();
		
		
		driver.findElement(By.xpath("//html//li[3]/a[1]")).click();

		
		driver.findElement(By.xpath("//a[@href='return.php']")).click();
		
		
		driver.findElement(By.xpath("//a[@href='return.php'][contains(text(),'Student')]")).click();
		driver.findElement(By.xpath("//a[@href='teacher_return.php']")).click();
		driver.findElement(By.xpath("//a[@href='#myModal4']")).click();

		driver.findElement(By.xpath("//div[@id='myModal4']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//input[@id='inputEmail']")).sendKeys("2015-12-14 11:21:17");
		driver.findElement(By.xpath("//div[@id='myModal4']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//input[@id='inputPassword']")).sendKeys("2015-12-14 11:21:27");

		driver.findElement(By.xpath("//div[@id='myModal4']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();

		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Mokhlesur Rahman"); //Valid
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
		
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("Rahman Mokhlesur"); //In_Valid >> Wrong Answer
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
		
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("08@gmail"); //In_Valid >> Wrong Answer
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
		
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("mokhles08@gmail.com"); //Valid
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
		
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys("08mokhles@gmail"); //Valid
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
		
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).sendKeys(" Rahman"); //Valid
		driver.findElement(By.xpath("//div[@id='example_filter']//label//input[@type='text']")).clear();
		 
	}
}
