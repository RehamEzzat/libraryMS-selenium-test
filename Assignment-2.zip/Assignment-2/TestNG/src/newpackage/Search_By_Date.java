package newpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Search_By_Date 
{
	/**
	 * @param args
	 */
	public static void main (String []args)
	{
		System.setProperty("webdriver.chrome.driver","F:\\FCI_Three\\New folder\\Chrome\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://localhost/library-master/member/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
		driver.findElement(By.name("username")).clear();
		driver.findElement(By.name("username")).sendKeys("Keya07");
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("anything' OR 'x'='x");
		driver.findElement(By.name("submit")).click();
		
	
		driver.findElement(By.xpath("//a[@href='#myModal2']")).click();
		
		//Invalid Wrong output

		driver.findElement(By.name("from")).sendKeys("01/01/0000");
		driver.findElement(By.name("to")).sendKeys("01/01/2017");	
		driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();
		
		//Invalid Wrong output
		driver.findElement(By.xpath("//a[@href='#myModal2']")).click();	
		driver.findElement(By.name("from")).sendKeys("0/0/0");
		driver.findElement(By.name("to")).sendKeys("01/01/2017");
		driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();

		//Invalid Wrong output

		driver.findElement(By.xpath("//a[@href='#myModal2']")).click();
		driver.findElement(By.name("from")).sendKeys("32/1/2000");
		driver.findElement(By.name("to")).sendKeys("01/12/2016");
		driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();

		//Invalid Wrong output

		driver.findElement(By.xpath("//a[@href='#myModal2']")).click();
		driver.findElement(By.name("from")).sendKeys("2/13/2000");
		driver.findElement(By.name("to")).sendKeys("01/5/2010");
		driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();

		//Invalid , Even it's Existed
		driver.findElement(By.xpath("//a[@href='#myModal2']")).click();
		driver.findElement(By.name("from")).sendKeys("15/9/2015");
		driver.findElement(By.name("to")).sendKeys("18/9/2015");
		driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();
		
		//Invalid , Even it's Existed
		driver.findElement(By.xpath("//a[@href='#myModal2']")).click();
		driver.findElement(By.name("from")).sendKeys("1992");
		driver.findElement(By.name("to")).sendKeys("2002");
		driver.findElement(By.xpath("//div[@id='myModal2']//div[@class='modal-body']//form[@class='form-horizontal']//div[@class='control-group']//div[@class='controls']//button[@type='submit']")).click();
		
		
		
	}
}
